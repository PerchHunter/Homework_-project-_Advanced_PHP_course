-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июл 30 2022 г., 18:03
-- Версия сервера: 8.0.19
-- Версия PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `online_store_advancedphp`
--

-- --------------------------------------------------------

--
-- Структура таблицы `baskets`
--

CREATE TABLE `baskets` (
  `id_basket` int NOT NULL,
  `id_user` int DEFAULT NULL,
  `id_good` int NOT NULL,
  `size` varchar(5) CHARACTER SET ucs2 COLLATE ucs2_general_ci DEFAULT NULL,
  `color` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `price` double NOT NULL DEFAULT '0',
  `quantity` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `brands_of goods`
--

CREATE TABLE `brands_of goods` (
  `id_brand` int NOT NULL,
  `brand_title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `brands_of goods`
--

INSERT INTO `brands_of goods` (`id_brand`, `brand_title`) VALUES
(10, 'Balenciaga'),
(3, 'BGN'),
(1, 'Brigitte Bardot'),
(2, 'Camaïeu'),
(11, 'Chanel'),
(12, 'Christian Dior'),
(7, 'Etam'),
(13, 'Givenchy'),
(14, 'Hermès'),
(4, 'Jules'),
(16, 'Kenzo'),
(9, 'Kookai'),
(15, 'Louis Vuitton'),
(17, 'Maison Margiela'),
(8, 'Morgan'),
(18, 'Nina Ricci'),
(5, 'Sisley'),
(6, 'Vicolo'),
(19, 'Yves Saint Laurent');

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE `categories` (
  `id_category` int NOT NULL,
  `status` int NOT NULL,
  `category_title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `id_major_category` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Внешний ключ для parent_id? Что по умолчанию?';

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id_category`, `status`, `category_title`, `id_major_category`) VALUES
(1, 0, 'Аксессуары', 1),
(2, 0, 'Кошельки', 1),
(3, 0, 'Джинсы', 1),
(4, 0, 'Футболки', 1),
(5, 0, 'Аксессуары', 2),
(6, 0, 'Куртки и пальто', 2),
(7, 0, 'Поло', 2),
(8, 0, 'Футболки', 2),
(9, 0, 'Рубашки', 2),
(10, 0, 'Аксессуары', 3),
(11, 0, 'Кошельки', 3),
(12, 0, 'Джинсы', 3),
(13, 0, 'Футболки', 3),
(14, 0, 'Рубашки', 3),
(15, 0, 'Рюкзаки', 3),
(16, 0, 'Сумки', 2),
(17, 0, 'Обувь', 3),
(18, 0, 'Свитера и трикотаж', 2),
(19, 0, 'Кепки', 1),
(20, 0, 'Джинсы', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `colors_of_goods`
--

CREATE TABLE `colors_of_goods` (
  `id_color` int NOT NULL,
  `color_title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `colors_of_goods`
--

INSERT INTO `colors_of_goods` (`id_color`, `color_title`) VALUES
(1, 'Белый'),
(2, 'Чёрный'),
(3, 'Синий'),
(4, 'Красный'),
(5, 'Серебряный'),
(6, 'Золотой'),
(7, 'Фиолетовый'),
(8, 'Хаки'),
(9, 'Сиреневый'),
(10, 'Мультиколор'),
(11, 'Морской'),
(12, 'Бирюзовый'),
(13, 'Серый'),
(14, 'Бронзовый'),
(15, 'Жёлтый'),
(16, 'Коричневый'),
(17, 'Тёмно-серый'),
(18, 'Лайм'),
(19, 'Голубой'),
(20, 'Бурый'),
(21, 'Янтарный'),
(22, 'Бежевый');

-- --------------------------------------------------------

--
-- Структура таблицы `designers`
--

CREATE TABLE `designers` (
  `id_designer` int NOT NULL,
  `designer_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `designers`
--

INSERT INTO `designers` (`id_designer`, `designer_name`) VALUES
(2, 'Christian Dior'),
(1, 'Coco Chanel'),
(10, 'Emanuel Ungaro'),
(5, 'Hubert Givenchy'),
(7, 'Jacques Fat'),
(6, 'Jean-Paul Gaultier'),
(8, 'Louis Vuitton'),
(4, 'Pierre Cardin'),
(9, 'Sonya Rikel'),
(3, 'Yves Saint Laurent');

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id_good` int NOT NULL,
  `name_good` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `price` double NOT NULL,
  `brand` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `major_category` int NOT NULL,
  `id_category` int NOT NULL,
  `status` int NOT NULL,
  `views` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id_good`, `name_good`, `price`, `brand`, `description`, `major_category`, `id_category`, `status`, `views`) VALUES
(34, 'Ремень', 3700, 'Levi\'sⓇ', 'Данный товар является частью проекта Brand planet - специального раздела нашего каталога, где мы собрали экологичные, этичные и благотворительные товары. Компания Levi Strauss & Co. поддерживает социальные проекты и оказывает целевую помощь по всему миру в рамках Фонда Леви Страусса (Levi Strauss Foundation). ', 1, 1, 1, 23),
(35, 'Ремень TheJam5', 1970, 'Quiksilver', 'Ремень Quiksilver The Jam имеет двухсторонний дизайн. Металлическая пряжка украшена тисненым логотипом. А открывашка для бутылок дополняет этот стильный аксессуар!', 1, 1, 1, 49),
(36, 'Ремень брючной', 3200, 'Levi\'sⓇ', 'Данный товар является частью проекта Brand planet - специального раздела нашего каталога, где мы собрали экологичные, этичные и благотворительные товары. Компания Levi Strauss & Co. поддерживает социальные проекты и оказывает целевую помощь по всему миру в рамках Фонда Леви Страусса (Levi Strauss Foundation). ', 1, 1, 1, 157),
(37, 'Очки солнцезащитные чёрные', 2390, 'Vans', 'Очки выполнены в стильном выдержанном черном цвете.\r\nОсобенностями данной модели являются оправы, имеющие форму перевернутой трапеции со скругленными углами и толстый ободок, позволяющий очкам с такой оправой визуально расширять верхнюю часть лица.\r\nДанная оправа является классической поэтому её можно носить практически с любой одеждой: купальник, джинсы с кроссовками или деловой костюм. Правильно подобранная модель не испортит образ, а лишь внесет особую изюминку и очарование.\r\nСтепень защиты очков UV400 - полная защита глаз от воздействия ультрафиолетового излучения. Имеют поляризационный эффект.', 1, 1, 1, 44),
(38, 'Очки солнцезащитные ', 2990, 'Vans', 'Солнцезащитные очки коллекции 2022 года с оправой “Авиатор”.', 1, 1, 1, 13),
(39, 'Часы Sport 20 Pink', 4990, 'Zdk', 'Смарт часы/браслет ZDK Sport 20 Pink. Шагомер, пульсометр, тонометр. Сенсорный дисплей. Уведомление о сообщениях и звонках, Защита от влаги (IP 68). Синхронизация со смартфоном по Bluetooth. Мониторинг сна, счетчик калорий и другие функции. Обратите внимание, что гарантия на товар подтверждается гарантийным талоном. Гарантийный срок товара исчисляется со дня передачи товара потребителю, что подтверждается кассовым чеком, либо уведомлением о вручении при доставке товара по почте.', 1, 1, 2, 43),
(40, 'Ремешок для часов 20 URB1 SILICONE STRAP S', 2240, 'Suunto', 'Подойдет для запястья 120-180 мм в обхвате. Подходит для часов Suunto 3 Fitness. Предназначен для повседневного использования и занятий спортом. ', 1, 1, 1, 14),
(41, 'Перчатки touchscreen NK ACDMY HPRWRM - HO20', 2999, 'Nike', 'Перчатки Nike Hyperwarm Academy защищают от холода, позволяя сосредоточиться на игре. Текстурированная область ладоней помогает удобно захватывать мяч, а накладки на кончиках пальцев для работы с сенсорными устройствами позволяют проверить телефон после игры, не снимая перчаток. Силиконовые зоны на пальцах и ладони улучшают сцепление с мячом. Накладки на большом и указательном пальцах для работы с сенсорными устройствами. Эластичные манжеты для надежной посадки.', 2, 5, 1, 29),
(42, 'Заколки 5 шт.', 3990, 'Fiona Franchimon No1 Hairpin', 'Создательница №1 HAIRPIN — Фиона Франшимон — парикмахер-стилист с более чем 20-летним опытом работы на модных показах и съемках\nФиона разрабатывала конструкцию шпильки в течение двух лет.\nЕй было очень важно получить прочный и гибкий аксессуар для волос, который при этом будет обладать элегантным, но лаконичным скандинавским дизайном.\nОсновательница и владелица одного из самых известных в Голландии салонов красоты \"Fiona Franchimon Professiona\", среди клиентов которого можно встретить не только звезд, но и королеву Нидерландов.Долгое время Фиона была ассистентом известного стилиста Орбэ Каналеса на многочисленных фэшн-шоу, а сейчас работает над образами для съемок в глянцевых журналах и показов модных домов от Armani до Jacquemus.', 3, 10, 1, 142),
(43, 'Ободок и резинка Trendy Treasure Kit', 4500, 'Invicibobble', 'Будьте ярче с подарочным набором аксессуаров для волос Invisibobble Trendy Treasure Kit.\nОбодок Invisibobble Hairhalo Trendy Treasure и мягкая резиночка Sprunchie Fade into Fab, выпущенные в коллаборации с ярким британским ювелирным брендом Rosie Fortescue Jewellery, — настоящее украшение для ваших волос.\nИзящная резиночка из мягкой ткани Sprunchie Fade into Fab, выполненная с красочным эффектом градиента, станет акцентной деталью в образе. Внешняя часть ободка Hairhalo Trendy Treasure инкрустирована сверкающими разноцветными фианитами. Трендовые по-детски непосредственные аксессуары добавят образу яркости и озорства.', 3, 10, 2, 171),
(44, 'Рубашка EDIPO', 26400, 'Maxx Mara Leisure', 'Рубашка EDIPO из коллекции бренда MAXMARA. Для выполнения модели мастера бренда использовали смесовый хлопковый материал, произведенный на японских ткацких станках, благодаря которым ткань получилась плотной, но в тоже время легкой с несминаемой текстурой. Изделие имеет украшенные манжетами длинные рукава и кокетку с вытачками на спинке. Застежка на пуговицы.', 2, 9, 1, 8),
(58, 'Джинсы', 1499, 'Zarina', 'Женские джинсы подчеркнут бедра, придадут стройности и визуально удлинят ноги, привлекая к вашей фигуре взгляды мужчин и женщин. Комфортная резинка на талии обеспечит идеальную посадку, а эффект потертости на карманах и слегка зауженные брючины добавят стиля образу. Их легко стилизовать с любым верхом и обувью, например, с пиджаком и сапогами, блузкой и туфлями, кардиганом и ботинками, создав свой неповторимый модный look. Модель изготовлена из плотного хлопка, представлена в двух оттенках голубого цвета, подойдет девушкам 42-52 размеров. Имеет шлицы для ремня, прорезные карманы по бокам и накладные - сзади. Качественная и доступная одежда ZARINA - выбор стильных женщин!', 2, 20, 1, 13),
(59, 'Джинсы ', 1799, 'Zarina', 'Женские джинсы подчеркнут бедра, придадут стройности и визуально удлинят ноги, привлекая к вашей фигуре взгляды мужчин и женщин. Комфортная резинка на талии обеспечит идеальную посадку, а эффект потертости на карманах и слегка зауженные брючины добавят стиля образу. Их легко стилизовать с любым верхом и обувью, например, с пиджаком и сапогами, блузкой и туфлями, кардиганом и ботинками, создав свой неповторимый модный look. Модель изготовлена из плотного хлопка, представлена в двух оттенках голубого цвета, подойдет девушкам 42-52 размеров. Имеет шлицы для ремня, прорезные карманы по бокам и накладные - сзади. Качественная и доступная одежда ZARINA - выбор стильных женщин!', 2, 20, 1, 1),
(60, 'Куртка утепленная ', 2799, 'BeFree', 'Демисезонная женская куртка свободного покроя оверсайз с горизонтальной прострочкой и синтепоновым утеплителем - Застежка на молнию и планку с кнопками - Рукава реглан - Высокий воротник - Боковые прорезные карманы - Однотонные пастельные расцветки - Демисезонный пуховик, в котором так приятно погулять по парку и насладиться долгожданным пробуждением природы или золотыми красками осени - Сочетай его с любимыми джинсами, брюками, юбками или платьями и создавай самые стильные зимние луки, в которых тебе будет максимально тепло и комфортно - Подойдет на позднюю осень и раннюю весну, а также на европейскую зиму - Вес утеплителя: 381-400 г/м2.', 2, 6, 1, 4),
(61, 'Куртка утепленная ', 3799, 'BeFree', 'Демисезонная женская куртка свободного покроя оверсайз с горизонтальной прострочкой и синтепоновым утеплителем - Застежка на молнию и планку с кнопками - Рукава реглан - Высокий воротник - Боковые прорезные карманы - Однотонные пастельные расцветки - Демисезонный пуховик, в котором так приятно погулять по парку и насладиться долгожданным пробуждением природы или золотыми красками осени - Сочетай его с любимыми джинсами, брюками, юбками или платьями и создавай самые стильные зимние луки, в которых тебе будет максимально тепло и комфортно - Подойдет на позднюю осень и раннюю весну, а также на европейскую зиму - Вес утеплителя: 381-400 г/м2.', 2, 6, 1, 7),
(62, 'Джинсы ', 2733, 'Bochetti', 'Всегда актуальная джинсовая классика - мужские джинсы BOCHETTI прямого кроя. Удобная средняя посадка выглядит безукоризненно на любом типе фигуры. В колене - свободное облегание. Мягкая, но в то же время плотная хлопковая ткань с небольшим содержанием эластана, делает джинсы удобными и приятными на ощупь. Джинсы универсальны и отлично сочетаются с одеждой любого стиля и уместны в любой ситуации: на каждый день или в офис, путешествие или отдых на природе. Также прямые классические джинсы BOCHETTI - это отличный подарок для мужчины любого возраста.', 1, 3, 1, 2),
(63, 'Джинсы ', 1990, 'Bochetti', 'Всегда актуальная джинсовая классика - мужские джинсы BOCHETTI прямого кроя. Удобная средняя посадка выглядит безукоризненно на любом типе фигуры. В колене - свободное облегание. Мягкая, но в то же время плотная хлопковая ткань с небольшим содержанием эластана, делает джинсы удобными и приятными на ощупь. Джинсы универсальны и отлично сочетаются с одеждой любого стиля и уместны в любой ситуации: на каждый день или в офис, путешествие или отдых на природе. Также прямые классические джинсы BOCHETTI - это отличный подарок для мужчины любого возраста.', 1, 3, 1, 26),
(64, 'Футболка', 7890, 'Marc O’Polo', 'Привнесёт динамичность в образ: повседневная футболка с эффектом tie-dye. В процессе окрашивания материал завязывается в определенных местах, а затем погружается в краситель. Этот процесс создаёт аутентичный узор. Изготовленная из чистого органического хлопка, футболка выполнена из мягкой ткани джерси. Свободный крой с классическим, эластичным круглым вырезом, короткими рукавами и прямой линией подола. Сочетайте её с однотонными брюками. ', 1, 4, 1, 13),
(65, 'Футболка', 2390, 'Marc O’Polo', 'Привнесёт динамичность в образ: повседневная футболка с эффектом tie-dye. В процессе окрашивания материал завязывается в определенных местах, а затем погружается в краситель. Этот процесс создаёт аутентичный узор. Изготовленная из чистого органического хлопка, футболка выполнена из мягкой ткани джерси. Свободный крой с классическим, эластичным круглым вырезом, короткими рукавами и прямой линией подола. Сочетайте её с однотонными брюками.', 1, 4, 1, 6),
(66, 'Кошелёк', 789, 'Automobili Lamborghini', 'Кошелек выполнен из натуральной кожи. Особенности: без застежки, внутри 2 отделения для купюр, 10 карманов для пластиковых карт.', 1, 2, 1, 3),
(67, 'Футболка ', 1200, 'Апрель', 'Женская базовая однотонная футболка из 100% натурального хлопка идеальной длины. Маст-хэв женского гардероба. Универсальная модель свободного покроя умеренный оверсайз с короткими рукавами и округлым вырезом горловины будет прекрасно смотреться с джинсами, брюками и юбкой, ее можно надеть в офис под кардиган или пиджак. Стильная футболка для повседневной носки, спортивная майка для бега и йоги, футболка для фитнеса - гигроскопична и не сковывает движений. Вместе с велосипедками - современная физкультурная форма для девушек. В коллекции футболок от бренда Апрель разнообразная палитра цветов: майка прекрасно подойдет для кастома, чистый холст для воплощения самых ярких идей. Чтобы насыщенный цвет нашей футболки продолжал Вас радовать после каждой стирки, пожалуйста, соблюдайте правила ухода за трикотажными изделиями: только машинная стирка (руками не стирать!) при температуре 40 градусов, без предварительного замачивания.', 2, 8, 1, 98),
(68, 'Поло', 745, 'oodji', 'Минималистичная модель без принтов, рисунков и надписей с круглым вырезом станет отличной базой для вашего гардероба, так как модель универсальна и подходит к любой одежде. Футболка выполнена в шести нежных цветах и идеально смотрится с джинсами и кроссовками в летних образах, а также в деловых образах в сочетании с костюмами под объемные жакеты. Модель станет отличной альтернативой классическим рубашкам и блузам. Создавай незабываемые образы вместе с Zarina!', 2, 7, 1, 1),
(69, 'Футболка ', 870, 'Апрель', 'Женская базовая однотонная футболка из 100% натурального хлопка идеальной длины. Маст-хэв женского гардероба. Универсальная модель свободного покроя умеренный оверсайз с короткими рукавами и округлым вырезом горловины будет прекрасно смотреться с джинсами, брюками и юбкой, ее можно надеть в офис под кардиган или пиджак. Стильная футболка для повседневной носки, спортивная майка для бега и йоги, футболка для фитнеса - гигроскопична и не сковывает движений. Вместе с велосипедками - современная физкультурная форма для девушек. В коллекции футболок от бренда Апрель разнообразная палитра цветов: майка прекрасно подойдет для кастома, чистый холст для воплощения самых ярких идей. Чтобы насыщенный цвет нашей футболки продолжал Вас радовать после каждой стирки, пожалуйста, соблюдайте правила ухода за трикотажными изделиями: только машинная стирка (руками не стирать!) при температуре 40 градусов, без предварительного замачивания.', 2, 8, 1, 3),
(70, 'Несессер детский', 580, 'Resenthel', 'Многофункциональный органайзер для удобного хранения средств личной гигиены, туалетных принадлежностей, косметики. Унисекс, благодаря стильному дизайну является предметом повседневного использования как женщинами, так и мужчинами. Несессер выполнен из влагостойкого материала, имеет прозрачные и сетчатые карманы для удобного хранения вещей, и крючок для подвешивания, что обеспечивает большую функциональность данной модели. ', 3, 10, 1, 14),
(71, 'Кошелёк детский', 430, 'Sela', 'Кошелек с эластичным ремешком выполнен из текстиля. Детали: застежка на магнитную кнопку, внутри текстильная подкладка, ремешок с застежкой на липучку.', 3, 11, 1, 5),
(72, 'Джинсы ', 1200, 'Acoola', 'Стильные поваренные джинсы-джоггеры синего цвета со средней посадкой для девочек. Выполнены из прочного хлопкового денима с потертостями без заплаток изнутри. Комфортный пояс на кулиске со шлевками и утягивающим шнурком для регулировки объема под индивидуальные параметры. Модель с пятью карманами и имитацией гульфика. Декоративный брелок в виде пушистого помпона. ', 3, 12, 1, 2),
(73, 'Джинсы', 1180, 'Acoola', 'Утеплённые джинсы Jogger на резинке с высокой посадкой для мальчиков, выполненные из хлопкового денима с искусственными потертостями. Подкладкой из принтованного в клеточку флиса. Модель с пятью карманами, застежкой на молнию и пуговицу.', 3, 12, 1, 8),
(74, 'Футболка Better Tee Kids', 2100, 'PUMA', 'Логотип Better Sportswear (прорезиненный принт) на груди. Материал содержит переработанные волокна – PUMA заботится о снижении воздействия на окружающую среду. Bye Dye – одно из решений PUMA, нацеленное на экономное использование ресурсов: применение неокрашенных натуральных волокон сокращает расход воды, необходимой для производственного процесса, поскольку исключены красители и отбеливатели. ', 3, 13, 1, 2),
(75, 'Рубашка ', 1999, 'PlayToday ', 'Рубашка текстильная с высоким содержанием хлопка - slim fit - приталенный силуэт - застежка на кнопки.', 3, 14, 1, 5),
(76, 'Рубашка', 1800, 'PlayToday', 'Рубашка в клетку- высокое содержание хлопка- regular fit - классический прямой силуэт- застежка на кнопки- на полочке карман с шевроном.', 3, 14, 1, 13),
(77, 'Рюкзак GRL YOUTH BP', 3490, 'Adidas Originals', 'Рюкзак выполнен из плотной ткани на основе полиэстера. Детали: одно отделение на молнии, внутри отсек для ноутбука/планшета, один внешний карман на молнии, два боковых кармана без застежки.', 3, 15, 1, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `goods_sizes_colors_brands`
--

CREATE TABLE `goods_sizes_colors_brands` (
  `id` int NOT NULL,
  `id_good` int NOT NULL,
  `id_size` int NOT NULL,
  `id_color` int NOT NULL,
  `id_brand` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `goods_sizes_colors_brands`
--

INSERT INTO `goods_sizes_colors_brands` (`id`, `id_good`, `id_size`, `id_color`, `id_brand`) VALUES
(1, 34, 2, 1, NULL),
(2, 34, 3, 2, NULL),
(3, 34, 3, 1, NULL),
(4, 34, 2, 5, NULL),
(5, 34, 3, 7, NULL),
(6, 35, 1, 1, NULL),
(7, 35, 1, 2, NULL),
(8, 35, 2, 3, NULL),
(9, 35, 4, 6, NULL),
(10, 35, 7, 2, NULL),
(11, 35, 3, 12, NULL),
(12, 36, 1, 3, NULL),
(13, 36, 2, 1, NULL),
(14, 36, 3, 5, NULL),
(15, 37, 5, 9, NULL),
(16, 37, 4, 17, NULL),
(17, 37, 4, 2, NULL),
(18, 37, 3, 1, NULL),
(19, 38, 2, 3, NULL),
(20, 38, 1, 5, NULL),
(21, 38, 1, 7, NULL),
(22, 38, 1, 9, NULL),
(23, 38, 1, 6, NULL),
(24, 39, 3, 3, NULL),
(25, 39, 2, 1, NULL),
(26, 39, 1, 1, NULL),
(27, 39, 1, 7, NULL),
(28, 40, 1, 1, NULL),
(29, 40, 1, 2, NULL),
(30, 40, 1, 3, NULL),
(31, 40, 1, 4, NULL),
(32, 41, 2, 2, NULL),
(33, 41, 1, 2, NULL),
(34, 41, 2, 4, NULL),
(35, 42, 3, 6, NULL),
(36, 42, 7, 18, NULL),
(37, 43, 2, 1, NULL),
(38, 43, 1, 1, NULL),
(39, 43, 1, 2, NULL),
(40, 43, 2, 4, NULL),
(41, 58, 3, 3, NULL),
(42, 58, 4, 3, NULL),
(43, 58, 6, 3, NULL),
(44, 59, 2, 3, NULL),
(45, 59, 3, 3, NULL),
(46, 60, 3, 22, NULL),
(47, 60, 3, 13, NULL),
(48, 61, 4, 13, NULL),
(49, 61, 5, 13, NULL),
(50, 61, 2, 1, NULL),
(51, 61, 4, 1, NULL),
(52, 62, 3, 3, NULL),
(53, 62, 4, 3, NULL),
(54, 62, 5, 3, NULL),
(55, 63, 4, 3, NULL),
(56, 63, 5, 3, NULL),
(57, 63, 6, 3, NULL),
(58, 63, 1, 13, NULL),
(59, 64, 2, 22, NULL),
(60, 64, 3, 8, NULL),
(61, 65, 3, 19, NULL),
(62, 65, 5, 19, NULL),
(63, 65, 1, 19, NULL),
(64, 66, 3, 16, NULL),
(65, 66, 3, 2, NULL),
(66, 67, 2, 1, NULL),
(67, 67, 3, 1, NULL),
(68, 68, 3, 8, NULL),
(69, 68, 4, 22, NULL),
(70, 69, 2, 20, NULL),
(71, 69, 3, 20, NULL),
(72, 70, 3, 11, NULL),
(73, 71, 3, 10, NULL),
(74, 72, 1, 3, NULL),
(75, 72, 2, 3, NULL),
(76, 73, 1, 3, NULL),
(77, 73, 2, 3, NULL),
(78, 74, 1, 4, NULL),
(79, 74, 1, 15, NULL),
(80, 74, 2, 15, NULL),
(81, 75, 1, 19, NULL),
(82, 75, 2, 19, NULL),
(83, 76, 1, 10, NULL),
(84, 76, 2, 10, NULL),
(85, 76, 3, 10, NULL),
(86, 77, 3, 13, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `goods_statuses`
--

CREATE TABLE `goods_statuses` (
  `id_status` int NOT NULL,
  `status_title` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `goods_statuses`
--

INSERT INTO `goods_statuses` (`id_status`, `status_title`) VALUES
(1, 'В наличии'),
(2, 'Нет на складе');

-- --------------------------------------------------------

--
-- Структура таблицы `major_categories`
--

CREATE TABLE `major_categories` (
  `id_category` int NOT NULL,
  `title_major_category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `major_categories`
--

INSERT INTO `major_categories` (`id_category`, `title_major_category`) VALUES
(4, 'Аксессуары'),
(3, 'Детям'),
(2, 'Женщинам'),
(1, 'Мужчинам');

-- --------------------------------------------------------

--
-- Структура таблицы `orders_auth_users`
--

CREATE TABLE `orders_auth_users` (
  `id_order` int NOT NULL,
  `id_user` int NOT NULL,
  `additional_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `product_id` int NOT NULL,
  `product_name` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `product_price` mediumint NOT NULL,
  `quantity` double NOT NULL,
  `total_price` mediumint NOT NULL,
  `category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `size` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `color` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `datetime_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_order_status` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `orders_auth_users`
--

INSERT INTO `orders_auth_users` (`id_order`, `id_user`, `additional_info`, `product_id`, `product_name`, `product_price`, `quantity`, `total_price`, `category`, `size`, `color`, `datetime_create`, `id_order_status`) VALUES
(13, 922307890, '', 39, 'Часы Sport 20 Pink', 4990, 1, 4990, 'Аксессуары', 'S', 'Белый', '2022-06-13 09:51:04', 4),
(14, 922307890, '', 39, 'Часы Sport 20 Pink', 4990, 1, 4990, 'Аксессуары', 'XS', 'Фиолетовый', '2022-06-13 09:51:04', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `orders_unauth_users`
--

CREATE TABLE `orders_unauth_users` (
  `id_order` int NOT NULL,
  `user_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_surname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_email` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `additional_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `product_id` int NOT NULL,
  `product_name` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `product_price` mediumint NOT NULL,
  `quantity` int NOT NULL,
  `total_price` mediumint NOT NULL,
  `category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `size` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `color` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `datetime_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_order_status` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `orders_unauth_users`
--

INSERT INTO `orders_unauth_users` (`id_order`, `user_name`, `user_surname`, `user_email`, `additional_info`, `product_id`, `product_name`, `product_price`, `quantity`, `total_price`, `category`, `size`, `color`, `datetime_create`, `id_order_status`) VALUES
(28, 'SERGEY', 'FEOKTISTOV', 'bbldyk@gmail.com', 'cdcdcdc', 36, 'Ремень брючной', 3200, 1, 3200, 'Аксессуары', 'M', 'Серебряный', '2022-06-13 11:22:48', 2),
(29, 'SERGEY', 'FEOKTISTOV', 'bbldyk@gmail.com', 'cdcdcdc', 36, 'Ремень брючной', 3200, 1, 3200, 'Аксессуары', 'XS', 'Синий', '2022-06-13 11:22:48', 0),
(30, 'SERGEY', 'FEOKTISTOV', 'bbldyk@gmail.com', 'cdcdcdc', 37, 'Очки солнцезащитные чёрные', 2390, 1, 2390, 'Аксессуары', 'M', 'Белый', '2022-06-13 11:22:48', 2),
(31, 'SERGEY', 'FEOKTISTOV', 'bbldyk@gmail.com', 'cdcdcdc', 35, 'Ремень TheJam5', 1970, 2, 3940, 'Аксессуары', 'XS', 'Белый', '2022-06-13 11:22:48', 2),
(32, 'Никита', 'Иванов', 'user@mail.ru', 'dcds', 36, 'Ремень брючной', 3200, 2, 6400, 'Аксессуары', 'S', 'Белый', '2022-07-04 16:15:21', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `order_statuses`
--

CREATE TABLE `order_statuses` (
  `id_order_status` int NOT NULL,
  `order_status_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `order_statuses`
--

INSERT INTO `order_statuses` (`id_order_status`, `order_status_name`) VALUES
(7, 'Возврат покупателем'),
(4, 'Готов к отправке покупателю'),
(6, 'Доставлен'),
(2, 'Обработан'),
(0, 'Отклонён'),
(5, 'Отправлен'),
(3, 'Передан на склад для комплектации'),
(1, 'Поступил  в обработку');

-- --------------------------------------------------------

--
-- Структура таблицы `photo_goods`
--

CREATE TABLE `photo_goods` (
  `id_photo` int NOT NULL,
  `path` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `id_good` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `photo_goods`
--

INSERT INTO `photo_goods` (`id_photo`, `path`, `id_good`) VALUES
(1, '1-1.jpg', 34),
(2, '1-2.jpg', 34),
(3, '1-3.jpg', 34),
(4, '2-1.jpg', 35),
(5, '2-2.jpg', 35),
(6, '2-3.jpg', 35),
(7, '3-1.jpg', 36),
(8, '3-2.jpg', 36),
(9, '3-3.jpg', 36),
(10, '4-1.jpg', 37),
(11, '4-2.jpg', 37),
(12, '4-3.jpg', 37),
(13, '4-4.jpg', 37),
(14, '5-1.jpg', 38),
(15, '5-2.jpg', 38),
(16, '5-3.jpg', 38),
(17, '5-4.jpg', 38),
(18, '6-1.jpg', 39),
(19, '6-2.jpg', 39),
(20, '6-3.jpg', 39),
(21, '6-4.jpg', 39),
(22, '7-1.jpg', 40),
(23, '8-1.jpg', 41),
(24, '8-2.jpg', 41),
(25, '9-1.jpg', 42),
(26, '9-2.jpg', 42),
(27, '10-1.jpg', 43),
(28, '10-2.jpg', 43),
(29, '11-1.jpg', 44),
(30, '11-2.jpg', 44),
(31, '11-3.jpg', 44),
(32, '11-4.jpg', 44),
(34, '58-1.jpg', 58),
(35, '58-2.jpg', 58),
(36, '58-3.jpg', 58),
(37, '58-4.jpg', 58),
(38, '59-1.jpg', 59),
(39, '59-2.jpg', 59),
(40, '59-3.jpg', 59),
(41, '60-1.jpg', 60),
(42, '60-2.jpg', 60),
(43, '60-3.jpg', 60),
(44, '60-4.jpg', 60),
(45, '61-1.jpg', 61),
(46, '61-2.jpg', 61),
(47, '61-3.jpg', 61),
(48, '61-4.jpg', 61),
(49, '62-1.jpg', 62),
(50, '62-2.jpg', 62),
(51, '62-3.jpg', 62),
(52, '63-1.jpg', 63),
(53, '63-2.jpg', 63),
(54, '63-3.jpg', 63),
(55, '64-1.jpg', 64),
(56, '64-2.jpg', 64),
(57, '64-3.jpg', 64),
(58, '65-1.jpg', 65),
(59, '65-2.jpg', 65),
(60, '65-3.jpg', 65),
(61, '66-1.jpg', 66),
(62, '66-2.jpg', 66),
(63, '66-3.jpg', 66),
(64, '67-1.jpg', 67),
(65, '67-2.jpg', 67),
(66, '67-3.jpg', 67),
(67, '67-4.jpg', 67),
(68, '68-1.jpg', 68),
(69, '68-2.jpg', 68),
(70, '68-3.jpg', 68),
(71, '69-1.jpg', 69),
(72, '69-2.jpg', 69),
(73, '69-3.jpg', 69),
(74, '70-1.jpg', 70),
(75, '70-2.jpg', 70),
(76, '71-1.jpg', 71),
(77, '71-2.jpg', 71),
(78, '71-3.jpg', 71),
(79, '72-1.jpg', 72),
(80, '72-2.jpg', 72),
(81, '72-3.jpg', 72),
(82, '73-1.jpg', 73),
(83, '73-2.jpg', 73),
(84, '73-3.jpg', 73),
(85, '74-1.jpg', 74),
(86, '74-2.jpg', 74),
(87, '74-3.jpg', 74),
(88, '75-1.jpg', 75),
(89, '75-2.jpg', 75),
(90, '75-3.jpg', 75),
(91, '76-1.jpg', 76),
(92, '76-2.jpg', 76),
(93, '76-3.jpg', 76),
(94, '77-1.jpg', 77),
(95, '77-2.jpg', 77),
(96, '77-3.jpg', 77);

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

CREATE TABLE `roles` (
  `id_role` int NOT NULL,
  `role_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id_role`, `role_name`) VALUES
(2, 'Админ'),
(1, 'Зарегистрированный пользователь'),
(0, 'Незарегистрированный пользователь');

-- --------------------------------------------------------

--
-- Структура таблицы `sizes_of_goods`
--

CREATE TABLE `sizes_of_goods` (
  `id_size` int NOT NULL,
  `size_title` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `sizes_of_goods`
--

INSERT INTO `sizes_of_goods` (`id_size`, `size_title`) VALUES
(1, 'XS'),
(2, 'S'),
(3, 'M'),
(4, 'L'),
(5, 'XL'),
(6, 'XXL'),
(7, 'XXXL');

-- --------------------------------------------------------

--
-- Структура таблицы `subscribers`
--

CREATE TABLE `subscribers` (
  `id` int NOT NULL,
  `email_subscriber` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `subscribers`
--

INSERT INTO `subscribers` (`id`, `email_subscriber`) VALUES
(4, 'b@mail.ru'),
(1, 'bbldyk@mail.ru');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id_user` int NOT NULL,
  `user_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `user_surname` varchar(50) DEFAULT NULL,
  `gender` varchar(11) DEFAULT NULL,
  `user_login` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_email` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_password` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `postal_address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `postal_code` int DEFAULT NULL,
  `telephone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_et_0900_as_cs DEFAULT NULL,
  `role` int NOT NULL,
  `user_last_action` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id_user`, `user_name`, `user_surname`, `gender`, `user_login`, `user_email`, `user_password`, `postal_address`, `postal_code`, `telephone`, `role`, `user_last_action`) VALUES
(922307890, 'SERGEY', 'FEOKTISTOV', 'male', 'bbldyk2', 'bbldyk@google.ru', 'a99932af71607381e99d50536661db42', 'Оренбургская область, Тоцкий район, Totskoe-10000-1', 2158051, '89107721712', 1, '2022-07-05 10:17:25'),
(922307899, 'Сергей', 'Феоктистов', 'male', 'admin', 'bbl@mail.ru', 'a99932af71607381e99d50536661db42', NULL, NULL, NULL, 2, '2022-07-05 10:17:51');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `baskets`
--
ALTER TABLE `baskets`
  ADD PRIMARY KEY (`id_basket`),
  ADD KEY `id_good` (`id_good`),
  ADD KEY `id_user` (`id_user`);

--
-- Индексы таблицы `brands_of goods`
--
ALTER TABLE `brands_of goods`
  ADD PRIMARY KEY (`id_brand`),
  ADD UNIQUE KEY `brand_title` (`brand_title`);

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id_category`),
  ADD KEY `parent_id` (`id_major_category`);

--
-- Индексы таблицы `colors_of_goods`
--
ALTER TABLE `colors_of_goods`
  ADD PRIMARY KEY (`id_color`);

--
-- Индексы таблицы `designers`
--
ALTER TABLE `designers`
  ADD PRIMARY KEY (`id_designer`),
  ADD UNIQUE KEY `designer_name` (`designer_name`) USING BTREE;

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id_good`),
  ADD KEY `id_category` (`id_category`),
  ADD KEY `major_category` (`major_category`);

--
-- Индексы таблицы `goods_sizes_colors_brands`
--
ALTER TABLE `goods_sizes_colors_brands`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `goods_statuses`
--
ALTER TABLE `goods_statuses`
  ADD PRIMARY KEY (`id_status`);

--
-- Индексы таблицы `major_categories`
--
ALTER TABLE `major_categories`
  ADD PRIMARY KEY (`id_category`),
  ADD UNIQUE KEY `name` (`title_major_category`);

--
-- Индексы таблицы `orders_auth_users`
--
ALTER TABLE `orders_auth_users`
  ADD PRIMARY KEY (`id_order`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_order_status` (`id_order_status`);

--
-- Индексы таблицы `orders_unauth_users`
--
ALTER TABLE `orders_unauth_users`
  ADD PRIMARY KEY (`id_order`);

--
-- Индексы таблицы `order_statuses`
--
ALTER TABLE `order_statuses`
  ADD PRIMARY KEY (`id_order_status`),
  ADD UNIQUE KEY `order_status_name` (`order_status_name`);

--
-- Индексы таблицы `photo_goods`
--
ALTER TABLE `photo_goods`
  ADD PRIMARY KEY (`id_photo`),
  ADD UNIQUE KEY `path` (`path`),
  ADD KEY `id_good` (`id_good`);

--
-- Индексы таблицы `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id_role`),
  ADD UNIQUE KEY `role_name` (`role_name`);

--
-- Индексы таблицы `sizes_of_goods`
--
ALTER TABLE `sizes_of_goods`
  ADD PRIMARY KEY (`id_size`);

--
-- Индексы таблицы `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email_subscriber` (`email_subscriber`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `user_login` (`user_login`),
  ADD UNIQUE KEY `user_email` (`user_email`),
  ADD KEY `role` (`role`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `baskets`
--
ALTER TABLE `baskets`
  MODIFY `id_basket` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=165;

--
-- AUTO_INCREMENT для таблицы `brands_of goods`
--
ALTER TABLE `brands_of goods`
  MODIFY `id_brand` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
  MODIFY `id_category` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT для таблицы `colors_of_goods`
--
ALTER TABLE `colors_of_goods`
  MODIFY `id_color` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT для таблицы `designers`
--
ALTER TABLE `designers`
  MODIFY `id_designer` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id_good` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT для таблицы `goods_sizes_colors_brands`
--
ALTER TABLE `goods_sizes_colors_brands`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT для таблицы `goods_statuses`
--
ALTER TABLE `goods_statuses`
  MODIFY `id_status` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `major_categories`
--
ALTER TABLE `major_categories`
  MODIFY `id_category` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `orders_auth_users`
--
ALTER TABLE `orders_auth_users`
  MODIFY `id_order` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT для таблицы `orders_unauth_users`
--
ALTER TABLE `orders_unauth_users`
  MODIFY `id_order` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT для таблицы `order_statuses`
--
ALTER TABLE `order_statuses`
  MODIFY `id_order_status` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `photo_goods`
--
ALTER TABLE `photo_goods`
  MODIFY `id_photo` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT для таблицы `roles`
--
ALTER TABLE `roles`
  MODIFY `id_role` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `sizes_of_goods`
--
ALTER TABLE `sizes_of_goods`
  MODIFY `id_size` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=922307900;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `baskets`
--
ALTER TABLE `baskets`
  ADD CONSTRAINT `baskets_ibfk_2` FOREIGN KEY (`id_good`) REFERENCES `goods` (`id_good`);

--
-- Ограничения внешнего ключа таблицы `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`id_major_category`) REFERENCES `major_categories` (`id_category`);

--
-- Ограничения внешнего ключа таблицы `goods`
--
ALTER TABLE `goods`
  ADD CONSTRAINT `goods_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `categories` (`id_category`),
  ADD CONSTRAINT `goods_ibfk_2` FOREIGN KEY (`major_category`) REFERENCES `major_categories` (`id_category`);

--
-- Ограничения внешнего ключа таблицы `orders_auth_users`
--
ALTER TABLE `orders_auth_users`
  ADD CONSTRAINT `orders_auth_users_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`),
  ADD CONSTRAINT `orders_auth_users_ibfk_2` FOREIGN KEY (`id_order_status`) REFERENCES `order_statuses` (`id_order_status`);

--
-- Ограничения внешнего ключа таблицы `photo_goods`
--
ALTER TABLE `photo_goods`
  ADD CONSTRAINT `photo_goods_ibfk_1` FOREIGN KEY (`id_good`) REFERENCES `goods` (`id_good`);

--
-- Ограничения внешнего ключа таблицы `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role`) REFERENCES `roles` (`id_role`),
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`role`) REFERENCES `roles` (`id_role`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
